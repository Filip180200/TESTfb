# Mock Social Media Website Tool

The Mock Social Media Website Tool is an open-source tool for conducting experimental, ecologically-valid research on social media behaviour.

[Please visit the website for the tool for more information](https://docs.studysocial.media)
